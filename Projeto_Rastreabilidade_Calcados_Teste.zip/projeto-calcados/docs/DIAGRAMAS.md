# Diagramas técnicos

Os blocos Mermaid podem ser visualizados no GitHub ou em um editor compatível.

## DER

```mermaid
erDiagram
 BANCAS ||--o{ USUARIOS : vincula
 BANCAS ||--o{ LOTES : recebe
 SERVICOS ||--o{ LOTES : contrata
 LOTES ||--|{ LOTE_GRADE : possui
 LOTES ||--|{ MOVIMENTACOES : registra
 LOTES ||--o{ PERDAS : apresenta
 USUARIOS ||--o{ MOVIMENTACOES : realiza
 USUARIOS ||--o{ PERDAS : informa
 BANCAS { bigint id PK
 string documento UK
 string nome
 boolean ativo }
 USUARIOS { bigint id PK
 bigint banca_id FK
 string email UK
 string senha
 string perfil
 boolean ativo }
 SERVICOS { bigint id PK
 string nome
 decimal valor_par
 boolean ativo }
 LOTES { bigint id PK
 string codigo UK
 bigint banca_id FK
 bigint servico_id FK
 string status
 int total_pares
 int total_perdas
 decimal valor_par
 date prazo
 datetime criado_em
 datetime enviado_em
 datetime concluido_em
 bigint versao }
 LOTE_GRADE { bigint lote_id PK,FK
 string numeracao PK
 int quantidade }
 MOVIMENTACOES { bigint id PK
 bigint lote_id FK
 bigint usuario_id FK
 string responsavel
 string anterior
 string posterior
 string tipo
 datetime ocorrido_em }
 PERDAS { bigint id PK
 bigint lote_id FK
 bigint usuario_id FK
 string tipo
 int quantidade
 datetime ocorrido_em }
```

## Leitura e atomicidade

```mermaid
sequenceDiagram
 participant C as Câmera
 participant V as Vue
 participant A as API Spring
 participant B as MySQL
 C->>V: Código identificado
 V->>V: Bloquear repetição contínua
 V->>A: POST leitura com token e ação
 A->>A: Validar token e usuário ativo
 A->>B: Iniciar transação e bloquear lote
 B-->>A: Lote atual
 A->>A: Validar banca, perfil e etapa
 alt Operação permitida
 A->>B: Atualizar status e inserir histórico
 B-->>A: Confirmar transação
 A-->>V: Novo status
 V->>V: Feedback verde
 else Regra inválida ou falha
 A->>B: Reverter transação
 A-->>V: Erro seguro
 V->>V: Feedback vermelho
 end
 V->>V: Liberar fila para próximo lote
```

## Classes principais

```mermaid
classDiagram
 LoteController --> LoteService
 LoteService --> Acesso
 LoteService --> Calculos
 LoteService --> LoteRepository
 LoteService --> MovimentacaoRepository
 LoteService --> PerdaRepository
 LoteRepository --> Lote
 Lote --> Banca
 Lote --> Servico
 Movimentacao --> Lote
 Perda --> Lote
 class LoteService {
 +salvar()
 +movimentar()
 +perda()
 +detalhe()
 }
 class Calculos {
 +aprovados()
 +percentual()
 +valor()
 +transicao()
 }
```

## Estados

```mermaid
stateDiagram-v2
 [*] --> Aguardando
 Aguardando --> Enviado: Operador da fábrica
 Aguardando --> Cancelado: Gestor com motivo
 Enviado --> Processamento: Operador da banca
 Processamento --> Concluido: Operador da banca
 Concluido --> [*]
 Cancelado --> [*]
```
