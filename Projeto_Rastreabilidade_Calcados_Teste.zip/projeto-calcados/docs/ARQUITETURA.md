# Arquitetura e decisões

## Fluxo de dados

O navegador executa Vue 3. Axios envia JSON e Bearer token à API relativa `/api`. Nginx (Docker) ou Vite (desenvolvimento) encaminha para Spring Boot. Controllers validam DTOs, services autorizam e aplicam regras, repositories acessam MySQL via Hibernate. Flyway cria e versiona o esquema. O painel usa SQL agregado parametrizado por JDBC dentro do mesmo ecossistema transacional Spring.

## Módulos e responsabilidades

| Camada | Arquivos | Responsabilidade |
|---|---|---|
| Entrada | `controller/*Controller.java` | Rotas, DTOs e códigos HTTP |
| Domínio | `service/LoteService.java`, `Calculos.java`, `CadastroService.java` | Regras, cálculos, transações e bloqueios |
| Consultas | `service/PainelService.java` | Agrupamentos no banco, filtros e paginação financeira |
| Dados | `entity/*.java`, `repository/*.java` | Entidades e acesso parametrizado |
| Segurança | `security/Seguranca.java`, `Acesso.java` | JWT, BCrypt, perfil e escopo por banca |
| Falhas | `exception/Erros.java` | Respostas seguras em português |
| Interface | `frontend/src/views` | Telas com dados reais |
| Componentes | `frontend/src/components` | Filtros, gráficos, paginação e feedback |
| Sessão | `frontend/src/stores/auth.js`, `api.js`, `router.js` | Pinia, Axios e guarda de navegação |
| Infraestrutura | `docker-compose.yml`, Dockerfiles, `nginx.conf` | Execução reproduzível |

## Segurança e concorrência

As operações de escrita do lote usam `@Transactional` e SELECT FOR UPDATE através de `PESSIMISTIC_WRITE`. O bloqueio serializa perdas e movimentações do mesmo lote. Assim, duas perdas concorrentes veem o total atualizado antes de decidir. `@Version` acrescenta detecção de atualização otimista. Status e histórico são gravados na mesma transação: falha em qualquer um reverte ambos.

A tabela de movimentações possui triggers MySQL bloqueando UPDATE e DELETE; a entidade é `@Immutable` e não há endpoints de mutação do histórico. Os nomes dos responsáveis são copiados para os eventos para preservar a identificação exibida mesmo se o nome do usuário mudar.

O valor por par é copiado do serviço ao criar o lote. Atualizações no catálogo não recalculam lotes antigos. Toda operação financeira usa BigDecimal/DECIMAL; JavaScript só formata valores recebidos.

JWT usa assinatura HS256 e expiração. A cada operação, a API consulta novamente o usuário ativo e perfil no banco. O token contém subject e validade, não o perfil como autoridade definitiva. Filtros de banca são aplicados no servidor; consultas diretas de detalhe, QR e mutações também validam o vínculo.

Não são enviados hashes de senha. Não há cookies de autenticação, por isso CSRF está desativado no modo Bearer. CORS amplo não é habilitado; o proxy mantém a mesma origem.

## Semântica dos indicadores

- Listas e painel: intervalo inclusivo de datas de criação em Brasília, implementado como limite inicial inclusivo/final exclusivo em UTC.
- Financeiro: intervalo de datas de conclusão, apenas status CONCLUIDO, agrupado por banca e mês local.
- Atraso: prazo anterior à data atual de Brasília e status diferente de CONCLUIDO/CANCELADO; inclui aguardando envio.
- Ciclo: média de horas entre envio e conclusão dos lotes concluídos do filtro.
- Total de pares/perdas do painel considera todos os lotes do filtro, incluindo cancelados (estes não têm perdas no fluxo normal).
- Evolução mostra os 30 últimos dias com registros no filtro, sem inventar dias sem registros.
- Agregações SQL por data usam UTC−3, vigente para Brasília nos períodos deste projeto; mudança futura da legislação de fuso exige revisão dessa expressão. As datas de limite e exibição usam `America/Sao_Paulo`.
- Atualização automática: 15 segundos; configure `VITE_POLL_MS` no build do frontend, se necessário.

## Ordem de desenvolvimento e decisões pendentes

1. Requisitos, entidades, migrações e infraestrutura.
2. Login, autorização e cadastros.
3. Lotes, preço contratado, movimentos, perdas e histórico.
4. Painel e consolidação financeira.
5. Interface, câmera e impressão.
6. Testes e documentação.

Confirmar com o professor: devolução registrada pela banca; uso de pares em vez de peças; desconto de defeito de fabricação; competência pela conclusão. Mantivemos as regras detalhadas atuais, sem alterar silenciosamente os documentos.
