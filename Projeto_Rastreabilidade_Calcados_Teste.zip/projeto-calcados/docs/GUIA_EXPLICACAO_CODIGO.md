# Guia de explicação do código

Este guia acompanha o código real. Abra os arquivos citados enquanto lê. As classes Java têm comentários de responsabilidade e regras; os componentes Vue separam estado, chamadas à API e apresentação. Os caminhos Java abaixo partem de `backend/src/main/java/br/edu/senai/rastreio/`.

## 1. Como o sistema se organiza

Arquivos: `RastreioApplication.java`, `controller/`, `service/`, `repository/`, `entity/`; no frontend, `main.js`, `App.vue`, `views/`.

O `main` inicia o Spring. Um controller atende a rota HTTP; um service decide se a ação é permitida; um repository lê ou grava o banco. A view Vue mostra o resultado. Exemplo: clicar em Criar lote chama `LoteController.criar`, que chama `LoteService.salvar`, que usa `LoteRepository`. Separar essas responsabilidades permite testar as regras sem depender de botões. RNF01/02/03.

## 2. Como o login funciona

Arquivos: `views/LoginView.vue`, `stores/auth.js`, `controller/AuthController.java`, `security/Seguranca.java`.

Passo a passo: formulário coleta credenciais → Pinia `entrar` envia POST → repository busca e-mail normalizado → `PasswordEncoder.matches` compara com BCrypt → é emitido JWT com identificação e expiração → Vue guarda o token em memória. O servidor não envia a senha nem seu hash. Exemplo: usuário desativado recebe a mesma mensagem genérica de credenciais inválidas. RF01, RNF16.

`Acesso.atual` consulta novamente o usuário em cada operação. Portanto, desativar um usuário bloqueia também tokens já emitidos. Logout apaga a memória local; expiração limita a validade de um token previamente copiado.

## 3. Como o Vue conversa com a API

Arquivos: `api.js`, `main.js`, `stores/auth.js`, `composables/useTask.js`.

Axios usa a origem relativa `/api`. Um interceptor adiciona o cabeçalho Bearer. Outro detecta 401 e retorna ao login. `useTask.run` bloqueia envio duplo, limpa mensagens antigas, trata falha e libera o formulário no `finally`. Exemplo: uma perda recusada por excesso mantém a observação digitada para correção. RNF02, RF17.

## 4. Como o Spring recebe requisições

Arquivos: `controller/LoteController.java`, `dto/Entradas.java`, `exception/Erros.java`.

`@PostMapping` identifica a rota. `@RequestBody` transforma JSON em DTO. `@Valid` verifica obrigatoriedade, limites e datas antes do método. O DTO de lote não inclui status/preço, impedindo atribuição direta desses campos pelo cliente. Exemplo: quantidade negativa produz HTTP 400 com mensagem de validação. HTTP 409 indica conflito com uma regra de negócio. RF05/15/19.

## 5. Como os dados são gravados

Arquivos: `entity/*.java`, `repository/*.java`, `resources/db/migration/V1__estrutura.sql`.

Cada `@Entity` corresponde a uma tabela. `@Id` é a chave; `@ManyToOne` representa vínculo, por exemplo lote → banca. A grade é uma coleção persistida em `lote_grade`. O repository utiliza consultas parametrizadas. O Flyway executa migrações uma vez e registra as versões aplicadas. Exemplo: ao reiniciar Docker, o volume mantém lotes e usuários; migrações existentes não são repetidas. RNF03/10/18.

## 6. Como um lote é criado

Arquivos: `views/LoteFormView.vue`, `service/LoteService.java` (`salvar`).

1. O formulário monta um mapa como `{"38":100,"39":200}`.
2. A API exige perfil GESTOR, banca/serviço ativos e prazo válido.
3. Soma as quantidades no servidor: 300 pares.
4. Copia o preço do serviço para o lote.
5. Gera `L-ANO-UUID` e salva com status aguardando envio.
6. Registra a criação no histórico dentro da mesma transação.

O UUID completo evita depender de um contador anual concorrente; UNIQUE reforça a proteção. Editar o preço do serviço posteriormente não muda o preço do lote. RF04–06/08.

## 7. Como o QR Code é gerado

Arquivo: `controller/LoteController.java` (`qr`).

Primeiro o serviço confere acesso ao lote. Depois ZXing transforma somente a string do código em uma matriz QR, com correção H e margem. `MatrixToImageWriter` gera um PNG. Não há preço, CPF/CNPJ ou token dentro do QR. O código é imutável: reimprimir produz a mesma identificação. RF06/07, RNF08/17.

No Vue, o PNG é obtido por Axios autenticado e exibido por URL temporária de objeto. Essa URL é revogada ao sair da página. O CSS de impressão mostra apenas a etiqueta e dimensiona o QR em 40 mm.

## 8. Como a câmera lê

Arquivos: `views/LeitorView.vue` (`iniciar`, `processar`), `scanGate.js` (`criarTrava`).

`Html5Qrcode.start` abre o dispositivo e chama a função de sucesso quando detecta um código. Não existe botão de captura. A trava evita requisições simultâneas e mantém o mesmo código bloqueado enquanto continua visível. Após ausência de 2,5 segundos ele pode ser tentado novamente; a regra do servidor ainda recusará etapa repetida.

O código manual chama a mesma função de processamento e a mesma API. Ao sair da tela, a câmera é parada e liberada. Erros de permissão/contexto inseguro orientam o operador a usar o campo manual. RF10/15–17, RNF04/05/07/14.

## 9. Como o status muda

Arquivos: `service/Calculos.java` (`transicao`), `service/LoteService.java` (`movimentar`), `security/Acesso.java`.

O cliente escolhe uma ação explícita, não um status arbitrário. `enviar` exige operador da fábrica e aguardando envio. `receber` exige operador da banca correta e enviado. `devolver` exige a banca correta e processamento. `cancelar` exige gestor, motivo e aguardando envio. Exemplo: ler saída duas vezes retorna 409 e não cria um segundo evento. RF08/11–15/17.

## 10. Por que o histórico é confiável

Arquivos: `entity/Movimentacao.java`, `LoteService.historico`, `V2__proteger_historico.sql`; testes `AtomicidadeTest`.

A transação inclui mudança do lote e inserção do evento. Se `saveAndFlush` do evento falhar, o Spring desfaz o status. O teste provoca exatamente essa falha e confere que o lote continua aguardando envio. O evento inclui antes/depois, responsável e instante; o nome do responsável também é preservado em texto. Não há rotas para editar/apagar. No MySQL, triggers acrescentam proteção contra UPDATE/DELETE. RF14, RNF18.

## 11. Como as perdas são calculadas

Arquivos: `LoteService.perda`, `Calculos.aprovados/percentual`, `entity/Perda.java`.

A API exige quantidade positiva, observação e tipo válido. Só permite perdas enquanto em processamento, na própria banca. Antes de somar, bloqueia a linha do lote. Duas pessoas não conseguem consumir ao mesmo tempo os mesmos pares disponíveis. Exemplo: 300 pares, 5 danificados + 2 extraviados + 1 defeito = 8 perdas, 292 aprovados, 2,67%. Após conclusão, perdas novas são recusadas. RF18–20.

## 12. Como o financeiro é calculado

Arquivos: `Calculos.valor`, `PainelService.financeiro`, `views/FinanceiroView.vue`.

`BigDecimal` multiplica aprovados pelo preço copiado na criação. A soma mensal considera apenas lotes concluídos, agrupados por banca e mês de conclusão em Brasília. Exemplo: 292 × R$ 2,50 = R$ 730,00. Lote aberto exibe previsão no detalhe, mas não entra como dívida definitiva. A mudança posterior do serviço para R$ 3,00 só vale para novos lotes. RF04/21.

## 13. Como o painel obtém dados

Arquivos: `PainelService.painel/filtro`, `DashboardView.vue`, `components/Grafico.vue`.

Filtros viram parâmetros de consultas SQL. COUNT/SUM/AVG calculam os indicadores no banco. O Chart.js recebe apenas resultados reais. A interface repete a consulta a cada 15 s usando os filtros aplicados e limpa o temporizador ao sair. O ciclo considera envio até conclusão; atraso considera prazo vencido e lote ainda aberto. Exemplo: um lote recém-concluído passa a aparecer nos totais após a próxima atualização. RF22–25.

## 14. Como o Docker executa

Arquivos: `docker-compose.yml`, `backend/Dockerfile`, `frontend/Dockerfile`, `frontend/nginx.conf`.

O Compose inicia MySQL e espera o healthcheck. O backend é compilado com Maven em uma etapa; a imagem final executa o JAR com usuário sem privilégios. O frontend é compilado por Vite e servido por Nginx. O banco usa volume separado. Segredos vêm do `.env`, que não entra no Git. Exemplo: o mesmo `docker compose up --build` constrói todas as partes no computador da equipe. RNF10–12.

## 15. O que mostrar ao professor

Abra nesta ordem: `docs/MATRIZ_REQUISITOS.md` → `docs/DIAGRAMAS.md` → `Entradas.java` → `LoteService.java` → `Calculos.java` → `Acesso.java` → `LeitorView.vue` → testes → Compose.

Explique cada decisão com um exemplo do fluxo de 300/8/292/R$730. Mostre a rejeição de outra banca e de leitura repetida; demonstre preço congelado. Por fim, leia `VALIDACAO.md`: diferencie teste automatizado, implementação e homologação física. A equipe ainda precisa realizar as cerimônias Scrum e confirmar as decisões do professor. RNF19/20.
