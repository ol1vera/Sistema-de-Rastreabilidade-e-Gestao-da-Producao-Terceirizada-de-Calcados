# Relatório final de validação

## Resultado desta entrega

Código-fonte implementado com API Spring Boot, frontend Vue, modelo e migrações MySQL, Compose, autenticação real, quatro perfis, cadastros, lotes, QR Code, leitura automática/manual, perdas, histórico, painel e financeiro. Há documentação acadêmica e testes. **Não foi homologado como 100% funcional em ambiente real.**

### Evidências executadas

| Verificação | Comando/procedimento | Resultado |
|---|---|---|
| Compilação e empacotamento Java | `mvn package` (Java 17 / Maven 3.9.9) | BUILD SUCCESS; JAR gerado |
| Testes Java unitários e HTTP com banco auxiliar H2 | JUnit / Spring Boot Test / MockMvc / Mockito | 45 execuções aprovadas, zero falhas e zero erros |
| Testes específicos MySQL | `MySqlTest`, habilitável com RUN_MYSQL_TESTS | 13 cenários ignorados; Docker indisponível |
| Testes frontend | `npm test` / Vitest | 14 testes aprovados em 3 arquivos |
| Compilação frontend | `npm run build` | Sucesso; rotas carregadas separadamente |
| QR gerado e reimpresso | Geração PNG + decodificação ZXing em teste | Conteúdo igual ao código; bytes preservados na reimpressão |
| Preço do lote | Alterar serviço de R$2,50 para R$3,00 | Lote antigo preservou R$2,50; novo usa R$3,00 |
| Fluxo oficial | Criar 300 pares, enviar, receber, perder 8, devolver | 292 aprovados; 2,67%; R$730,00; histórico de 4 eventos |
| Segurança | Token ausente/adulterado/expirado, usuário desativado, perfil/banca indevidos | Operações bloqueadas; sem dados da outra banca |
| Atomicidade | Falha simulada ao inserir histórico | Status revertido no H2 |
| Concorrência | Duas perdas de 200 em lote de 300 ao mesmo tempo | Uma aceita, outra recusada; total final 200 no H2 |
| Câmera simulada | Callback html5-qrcode no teste de componente | Chamada correta à API, feedback e liberação; não é câmera física |

O Surefire informa 58 testes encontrados: 45 executados e 13 ignorados. Os 12 cenários de FluxoBase são repetidos em três contextos (integração, spy para atomicidade e concorrência); portanto 45 não representa 45 cenários distintos. Somando frontend, foram **59 execuções automatizadas aprovadas**.

Evidências: `docs/evidencias/backend-resumo.json`, `backend-build.txt`, `frontend-testes.txt` e `frontend-build.txt`. O ambiente de compilação estava em outro fuso; os horários dos logs não alteram a configuração de Brasília usada pela aplicação. Durante preparação, o Mockito inline não conseguiu anexar agente à JVM; foi configurado o mock maker de subclasses e a suíte final passou. Logs de falha proposital no teste de rollback são esperados, não falhas da suíte.

## O que não foi executado

- Inicialização real do Docker Compose e persistência após reinício.
- MySQL 8.0, migrações Flyway, triggers e compatibilidade de consultas no InnoDB. H2 é um auxiliar exclusivo de teste; a aplicação entregue usa MySQL.
- E2E Playwright em navegador. O arquivo foi escrito, mas não executado; não havia controle de navegador disponível neste fluxo.
- Inspeção visual real em desktop/tablet/celular.
- Webcam física, câmera de smartphone, impressão e leitura de etiqueta danificada.
- HTTPS publicado e medição desde câmera apontada até confirmação (meta ≤2 s).
- Medição de abertura completa do painel com base representativa (meta ≤3 s).
- Deploy remoto, push GitHub, cerimônias Scrum ou aprovação do professor.

Essas pendências estão mapeadas individualmente nos 46 requisitos. Há procedimentos reproduzíveis no README e em TESTES_MANUAIS.md. O próximo marco é executar `docker compose up --build` e `RUN_MYSQL_TESTS=true mvn test` em máquina com Docker, seguido do fluxo no navegador e testes de dispositivo.

## Limites e decisões explícitas

- A banca confirma a devolução; isso não comprova por si só o recebimento físico na fábrica. Mantido conforme RF13, a confirmar com o professor.
- Defeito de fabricação desconta pagamento e perdas são em pares. Responsabilidade financeira pendente de confirmação.
- Competência financeira pela conclusão. Filtros do painel pela criação.
- CPF/CNPJ: validador de documentos numéricos de 11/14 dígitos. CNPJ alfanumérico não é suportado nesta versão.
- Token só em memória; recarregar exige login. Logout local não revoga um token copiado; expiração ou desativação bloqueiam seu uso.
- Sem recuperação de senha por e-mail. Administrador pode definir nova senha pela edição de usuário.
- A consulta por código parcial usa LIKE; em volumes muito grandes pode exigir índice/estratégia específica. Agregações e índices foram implementados, mas metas de desempenho não foram medidas.
- Triggers protegem contra edição operacional e SQL acidental, não contra um administrador com poderes para remover o esquema.
- A configuração MySQL permite criar triggers com o usuário do ambiente de demonstração. Em produção, convém separar usuário de migrações e usuário de execução.
- Sem publicação no Sites: o runtime de hospedagem disponível não executa o backend Java com MySQL exigido pelo projeto.

## Critério para apresentação

O aluno deve saber explicar o fluxo e executar os procedimentos pendentes antes de declarar atendimento integral dos RNFs. A entrega inclui o código e a documentação para essa validação, sem atribuir aprovação a testes não realizados.
