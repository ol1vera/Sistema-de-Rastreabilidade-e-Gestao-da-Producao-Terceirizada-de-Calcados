# Casos de uso

## UC01 — Autenticar
Ator: qualquer usuário. Objetivo: entrar com seu perfil. Pré-condição: usuário ativo cadastrado. Fluxo: informar e-mail e senha → validar BCrypt → emitir JWT → direcionar. Alternativas: credenciais inválidas/usuário inativo retornam 401; token vencido pede novo login. Pós-condição: sessão em memória com validade. RF01, RNF16/17.

## UC02 — Administrar cadastros
Ator: administrador. Objetivo: manter usuários, bancas e serviços. Pré-condição: login ADMIN. Fluxo: abrir cadastro → inserir campos → validar → salvar → atualizar lista. Alternativas: CPF/CNPJ inválido, e-mail duplicado, operador sem banca ou senha curta recusados. Pós-condição: cadastro persistido; desativação preserva histórico. RF02–04.

## UC03 — Criar lote
Ator: gestor. Pré-condição: banca e serviço ativos. Fluxo: preencher programação/modelo/cor/prazo → grade → somar pares → salvar preço contratado e identificador → registrar criação → gerar etiqueta. Alternativas: grade vazia, total zero, prazo passado recusados. Pós-condição: lote aguardando envio. RF05–07.

## UC04 — Editar ou cancelar
Ator: gestor. Pré-condição: aguardando envio. Fluxo: abrir detalhe → editar campos ou informar motivo de cancelamento → validar e registrar evento. Alternativas: lote enviado/concluído/cancelado não pode ser editado; motivo vazio recusado; serviço não pode mudar. Pós-condição: histórico preservado, lote atualizado/cancelado. RF08.

## UC05 — Registrar saída
Ator: operador da fábrica. Pré-condição: lote aguardando envio. Fluxo: leitor na ação Saída → apontar câmera → validar código e perfil → transação atualiza e registra → feedback verde. Alternativas: repetição/fora de ordem gera 409; câmera indisponível permite código manual. Pós-condição: ENVIADO_BANCA. RF10/11/14–17.

## UC06 — Receber na banca
Ator: operador da banca vinculada. Pré-condição: lote enviado à sua banca. Fluxo: selecionar Recebimento → ler → conferir banca/etapa → atualizar para processamento. Alternativas: outra banca recebe 404 sem dados; repetição recusada. Pós-condição: EM_PROCESSAMENTO e evento imutável. RF12/14–17.

## UC07 — Registrar perdas
Ator: operador da banca vinculada. Pré-condição: em processamento. Fluxo: detalhe → tipo/quantidade/observação → confirmar → bloquear lote → conferir soma → persistir perda e total. Alternativas: excesso, tipo inválido, zero/negativo ou lote concluído recusados. Pós-condição: aprovados/percentual/previsão recalculados. RF18–20.

## UC08 — Devolver
Ator: operador da banca. Pré-condição: em processamento e perdas já registradas. Fluxo: selecionar Devolução no leitor → ler etiqueta → validar → registrar conclusão. Alternativas: perdas pendentes devem ser registradas antes da leitura; repetição recusada. Pós-condição: CONCLUIDO; valor consolidado, histórico preservado, novas perdas bloqueadas. RF13/21.

## UC09 — Consultar painel e financeiro
Ator: gestor ou administrador. Pré-condição: login autorizado. Fluxo: selecionar período/banca/status → aplicar → consultar totais/gráficos → abrir lotes atrasados → acompanhar atualização automática. Financeiro agrupa concluídos por banca/mês. Alternativas: sem dados apresenta estado vazio; erro mantém a última informação com aviso. Pós-condição: informação visualizada sem alterar operação. RF09/21–25.
