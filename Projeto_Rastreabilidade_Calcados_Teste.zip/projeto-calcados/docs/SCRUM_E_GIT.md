# Organização Scrum e versionamento

## Papéis e cerimônias

Product Owner: professor/cliente. Scrum Master: líder do grupo ou rodízio. Desenvolvimento: alunos. A equipe deve preencher os nomes e confirmar duração das sprints com o professor; nenhum encontro ou aprovação foi inventado.

Organize o quadro em Backlog, Pronto para desenvolver, Em desenvolvimento, Em testes e Concluído. Na planning, escolha histórias pelos critérios; na daily, registre progresso/bloqueios; na review, demonstre o fluxo; na retrospectiva, registre uma melhoria executável. Testes e documentação fazem parte da definição de pronto.

## Backlog proposto

Estimativas abaixo são relativas (pontos), para revisão da equipe. P1 é essencial; P2 é acabamento/homologação. Todas as histórias possuem implementação entregue, mas itens físicos, infraestrutura e cerimônias só devem ir para Concluído após evidência.

| História | Como / quero / para | RF/RNF | Aceitação verificável | Prioridade | Pontos | Dependência |
|---|---|---|---|---|---|---|
| US01 | Usuário quer autenticar para acessar seu perfil | RF01; RNF16/17 | Login válido, inválido, expirado e desativado; outra banca não acessível | P1 | 5 | Banco |
| US02 | Admin quer cadastrar equipe/bancas para organizar vínculos | RF02/03 | Validação de documento e operador com banca, desativação sem exclusão | P1 | 5 | US01 |
| US03 | Admin quer precificar serviços para contratar produção | RF04 | Alteração do catálogo não muda lote existente | P1 | 3 | US02 |
| US04 | Gestor quer criar/editar/cancelar lotes para controlar programação | RF05/06/08 | Grade somada, código único, motivo de cancelamento, bloqueio após envio | P1 | 8 | US02/03 |
| US05 | Gestor quer imprimir etiqueta para identificar fisicamente | RF07; RNF08 | QR correto, impressão ≥3 cm, reimpressão estável | P1 | 3 | US04 |
| US06 | Operador quer ler webcam/manual para registrar saída e recebimento | RF10–12/15–17; RNF04/05/07/09/13/14 | Ordem/perfil/banca conferidos, feedback, sem duplicação contínua | P1 | 8 | US04/05 |
| US07 | Banca quer registrar perdas/devolver para concluir produção | RF13/18–20 | Tipos, limite concorrente, aprovação e conclusão | P1 | 8 | US06 |
| US08 | Gestor quer linha do tempo para auditar movimentações | RF14/24; RNF18 | Histórico imutável e rollback de falha | P1 | 5 | US06/07 |
| US09 | Gestor quer financeiro por banca/mês para conhecer valores | RF21 | Só concluídos, preço contratado, total por período | P1 | 5 | US07 |
| US10 | Gestor quer painel e filtros para acompanhar operação | RF09/22/23/25; RNF06/15/21 | Filtros, atraso, ciclo, atualização e paginação | P1 | 8 | US08/09 |
| US11 | Equipe quer Docker e guia para reproduzir a instalação | RNF01–03/10–12 | Construção limpa, migrações, volume e segredos externos | P1 | 5 | US01–10 |
| US12 | Equipe quer testes e documentação para apresentar com segurança | RNF19/20; RF01–25 | Matriz completa, diagramas, testes e pendências explícitas | P2 | 8 | Todas |

## Sprints propostas

- Sprint A: US01–04, modelagem e infraestrutura base.
- Sprint B: US05–08, câmera e rastreabilidade.
- Sprint C: US09–12, painel, consolidação, homologação e apresentação.

A duração e capacidade dependem da turma. A ordem acima é uma proposta, não registro de sprints efetivamente realizadas.

## Git local entregue

O pacote inclui `historico-git.bundle`, com repositório local e branches `main`, `develop`, `feature/sistema` e `test/testes-integracao`. O código foi verificado na branch de testes antes da integração final. Não foi publicado em GitHub nem criado um repositório remoto.

Para recuperar todo o histórico em outra pasta:

```sh
git clone historico-git.bundle rastreio-versionado
cd rastreio-versionado
git branch -a
git switch develop
```

O ZIP também contém os arquivos diretamente, para facilitar a leitura sem Git. Não misture alterações simultâneas entre a cópia extraída e a cópia clonada.

## Fluxo da equipe a partir desta entrega

```sh
git switch develop
git switch -c feature/nome-da-funcionalidade
# Implementar, revisar, documentar e commitar.
git switch -c test/nome-dos-testes
# Executar testes backend/frontend e testes do requisito.
git add .
git commit -m "test: validar funcionalidade"
git switch develop
git merge --no-ff test/nome-dos-testes
# Após review e homologação da release:
git switch main
git merge --no-ff develop
```

Antes de qualquer push, confirme que `.env`, senhas, volumes e dados operacionais não foram adicionados. Configure nome/e-mail pessoais no Git da equipe. O histórico inicial usa identidade local genérica `Equipe Rastreio`.
