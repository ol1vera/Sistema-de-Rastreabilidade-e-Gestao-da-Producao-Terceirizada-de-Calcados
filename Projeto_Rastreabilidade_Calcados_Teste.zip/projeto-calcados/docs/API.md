# API REST

Base `/api`, JSON UTF-8. O login retorna `{token, usuario, expiraEm}`. Envie `Authorization: Bearer <token>` nas demais chamadas. A documentação interativa está em `/swagger-ui.html`; o contrato gerado em `/v3/api-docs`. A documentação é pública, mas executar operações exige autenticação e perfil.

| Método | Caminho | Acesso | Função |
|---|---|---|---|
| POST | /auth/login | Público | E-mail/senha, emissão do token |
| GET | /auth/me | Autenticado | Usuário ativo sem hash |
| GET | /bancas | Autenticado | Bancas; operador de banca só sua banca |
| POST / PUT | /bancas e /bancas/{id} | Admin | Criar/editar/desativar logicamente |
| GET | /servicos | Admin/Gestor | Catálogo |
| POST / PUT | /servicos e /servicos/{id} | Admin | Serviço e preço |
| GET / POST / PUT | /usuarios e /usuarios/{id} | Admin | Listar/criar/editar/desativar |
| GET | /lotes | Autenticado, com escopo | Lista paginada |
| POST | /lotes | Gestor | Criar lote |
| PUT | /lotes/{codigo} | Gestor | Editar antes de enviar |
| GET | /lotes/{codigo} | Autenticado, com escopo | Detalhe, perdas e linha do tempo |
| GET | /lotes/{codigo}/qrcode | Autenticado, com escopo | PNG contendo somente o código |
| POST | /lotes/{codigo}/cancelar | Gestor | Motivo obrigatório |
| POST | /lotes/leitura/enviar | Operador fábrica | Saída |
| POST | /lotes/leitura/receber | Operador banca | Recebimento |
| POST | /lotes/leitura/devolver | Operador banca | Conclusão |
| POST | /lotes/{codigo}/perdas | Operador banca | Registrar perda |
| GET | /dashboard | Admin/Gestor | Indicadores e gráficos |
| GET | /relatorios/financeiro | Admin/Gestor | Consolidação por banca/mês |

Listas: `page` inicia em zero, `size` limitado a 100. Resposta contém `content`, `number`, `totalElements`, `totalPages` e `size` (catálogos/lotes). Lotes aceitam `busca`, `status`, `bancaId`, `inicio`, `fim`. Catálogos aceitam `busca` por nome. Dashboard aceita período/banca/status. Financeiro aceita período/banca/página, com totalDevido global no filtro.

Datas de filtro e prazo: `aaaa-mm-dd`; instantes de eventos: ISO 8601 UTC. A interface converte para português e Brasília.

### Criar lote

```json
{"programacao":"P-001","modelo":"Tênis","cor":"Preto","bancaId":1,"servicoId":1,"prazo":"2027-01-20","grade":{"38":100,"39":200}}
```

Use IDs reais de `/bancas` e `/servicos` e prazo não anterior ao dia da execução. Não envie status, preço contratado ou total: o servidor decide esses valores.

### Leitura

```json
{"codigo":"L-2026-CODIGO_REAL_GERADO_PELO_SISTEMA"}
```

### Perda

```json
{"tipo":"DANIFICADA","quantidade":8,"observacao":"Falha na costura"}
```

### Erros

```json
{"mensagem":"As perdas não podem superar o total do lote."}
```

Validações de campos também retornam `campos`. HTTP 201 criação; 200 consulta/alteração; 400 entrada inválida; 401 token/credenciais; 403 perfil proibido; 404 lote ausente/inacessível; 409 regra de estado/duplicidade; 500 falha interna sem detalhes sensíveis. A saída de QR é binária PNG.

Não existe rota de alteração genérica do status. Não existe DELETE para histórico, perdas ou cadastros. Swagger documenta os DTOs reais via springdoc.
