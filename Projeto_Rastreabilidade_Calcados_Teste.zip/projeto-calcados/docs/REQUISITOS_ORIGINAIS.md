# proposta 1 web(1).docx

Documento Oficial do Projeto

Sistema de Rastreabilidade e Gestão da Produção Terceirizada de Calçados

Instituição: SENAI Nova Serrana (CFP Geny José Ferreira)

Área: Tecnologia da Informação

Stack Tecnológica: Java (Spring Boot) + Vue.js + MySQL + Docker

1. Histórico e Contexto do Problema

A terceirização de etapas na indústria de calçados envolve a movimentação constante de programações de produção e materiais entre as fábricas e as bancas (prestadores de serviços terceirizados). Historicamente, esse fluxo é gerido por controles manuais ou descentralizados (papel, planilhas isoladas), gerando:

Dificuldade para rastrear quando um lote foi enviado, recebido, processado ou devolvido.

Falta de transparência sobre os volumes produzidos e os valores devidos aos serviços executados.

Ausência de controle sistematizado de perdas e desperdícios durante o processo produtivo.

Para solucionar essas dores, este projeto visa desenvolver uma aplicação web responsiva (com suporte opcional a dispositivos móveis) para sistematizar, rastrear e dar transparência a esse fluxo produtivo por meio de identificação por QR Code e leitura via webcam ou câmera de celular.

2. Guia de Levantamento de Requisitos (Para os Alunos Elaborarem)

Com base no problema apresentado, a equipe deverá analisar a demanda e registrar formalmente os Requisitos Funcionais (RF) e Requisitos Não Funcionais (RNF) da aplicação, respondendo às questões de análise abaixo:

📋 Guia para Definição dos Requisitos Funcionais (RF)

(O que o sistema deve FAZER?)

Gestão de Lotes: Como o sistema deve identificar unicamente cada lote/programação de calçados enviado à banca? Que informações básicas esse lote precisa conter ao ser criado?

Rastreamento do Fluxo: Quais são as etapas/status obrigatórios pelos quais um lote passa desde a saída da fábrica até o retorno? Como a câmera/webcam atuará em cada uma dessas etapas?

Controle de Exceções e Perdas: Como e em qual etapa o usuário deverá registrar problemas como peças danificadas, extraviadas ou com defeito de fabricação?

Visibilidade e Gestão: O que a tela principal (dashboard/painel) precisa exibir para que o gestor saiba exatamente a situação da produção em tempo real?

⚙️ Guia para Definição dos Requisitos Não Funcionais (RNF)

(Como o sistema deve SER ou se COMPORTAR?)

Tecnologia: Quais linguagens, frameworks e bancos de dados foram especificados para a construção do Backend, Frontend e Banco de Dados?

Usabilidade e Hardware: O leitor de QR Code deve funcionar obrigatoriamente por qual tipo de dispositivo primário? E secundário? Como a interface deve se comportar em telas de diferentes tamanhos?

Implantação e Portabilidade: Como o ambiente da aplicação (backend + banco de dados) deve ser empacotado para garantir que funcione em qualquer computador sem erros de configuração?

Desempenho e Operação: Como garantir que o processo de leitura do QR Code na linha de produção seja rápido e não trave a rotina do operador?

3. Metodologia de Gestão (Scrum)

Os alunos deverão organizar o desenvolvimento utilizando o framework Scrum:

Papéis: Product Owner (Professor/Cliente), Scrum Master (Lider do grupo ou revezamento) e o Time de Desenvolvimento (Alunos).

Sprints: O projeto será dividido em ciclos de entregas (Sprints) com duração definida pelo professor.

Backlog do Produto: Gestão das tarefas utilizando ferramentas como Trello, GitHub Projects ou Jira, registrando o progresso das Histórias de Usuário (User Stories).

4. Padrões de Versionamento (Git e Branches)

O código-fonte do projeto deve obrigatoriamente ser versionado no Git, seguindo a seguinte estrutura de branches:

main / master: Versão estável e oficial pronta para apresentação.

develop: Branch principal de integração do código desenvolvido pela equipe.

feature/<nome-da-funcionalidade>: Branches criadas individualmente para desenvolver novas telas ou APIs (ex: feature/cadastro-lotes, feature/leitor-qrcode).

test/<nome-dos-testes>: Branches obrigatórias para realização de testes integrados e validações antes de mesclar na develop.

5. Documentação Técnica Exigida

A entrega final do projeto deve vir acompanhada da seguinte documentação técnica:

Casos de Uso: Descrição textual dos principais fluxos do sistema.

Requisitos Funcionais e Não Funcionais: Documento detalhado (conforme seção 2).

Diagrama de Banco de Dados (DER): Modelagem relacional das tabelas (ex: Usuários, Lotes, Movimentações, Bancas).

Diagrama de Sequência: Representação da comunicação entre Frontend, Backend e Banco durante a leitura do QR Code e registro de movimentação.

Diagrama de Classes (Opcional): Visão estrutural das principais classes do backend Spring Boot.

6. Sugestão de Etapas do Projeto

Etapa 1: Definição do escopo, modelagem do banco de dados e desenho dos diagramas.

Etapa 2: Configuração do ambiente, estruturação do Backend (Spring Boot + MySQL) e criação dos endpoints REST básicos.

Etapa 3: Desenvolvimento do Frontend (Vue.js) e integração com a API.

Etapa 4: Implementação da biblioteca de leitura de QR Code (via webcam/navegador) e regras de movimentação.

Etapa 5: Containerização da aplicação com Docker Compose, testes finais utilizando as branches de teste e organização do repositório Git.

7. Arquitetura e Guia de Execução (Docker)

Para garantir que o sistema funcione de forma padronizada e sem falhas de ambiente, o projeto deverá contar com um arquivo docker-compose.yml na raiz do repositório, permitindo subir o banco de dados MySQL e a aplicação de forma automatizada.

Exemplo de Estrutura do Docker Compose

Serviço 1 (Banco de Dados): MySQL 8.0 configurado com volume persistente.

Serviço 2 (Backend): Container contendo a aplicação Spring Boot empacotada em arquivo .jar.

8. Detalhamento do Funcionamento do Sistema (100% Funcional)

Para ser considerado 100% funcional, o sistema entregue pelos alunos deve cumprir o seguinte fluxo operacional de ponta a ponta:

Acesso Inicial: O usuário acessa a aplicação via navegador web no computador (utilizando a webcam) ou via smartphone (responsivo). Realiza o login no sistema.

Geração do Lote: O gestor da fábrica cadastra uma nova programação de calçados, gerando automaticamente um QR Code exclusivo para aquele lote.

Saída da Fábrica: O operador posiciona a câmera (webcam) para ler o QR Code do lote no momento do despacho. O sistema registra instantaneamente o status como "Enviado à Banca".

Recebimento na Banca: Ao chegar na banca terceirizada, o operador lê o mesmo QR Code, alterando o status para "Em Processamento".

Registro de Perdas e Retorno: Durante a finalização, se houver perdas, o terceirizado registra a quantidade de peças avariadas. Em seguida, realiza a leitura de retorno do lote, atualizando o status para "Concluído/Na Fábrica".

Consolidação: O painel gerencial exibe o histórico completo de movimentações, o tempo de ciclo do lote e o resumo das perdas, permitindo a tomada de decisão ágil pelo gestor.

# Requisitos_Funcionais_e_Nao_Funcionais(1).docx

Requisitos Funcionais e Não Funcionais

Projeto: Sistema de Rastreabilidade e Gestão da Produção Terceirizada de CalçadosInstituição: SENAI Nova Serrana (CFP Geny José Ferreira) – Tecnologia da InformaçãoStack: Java (Spring Boot) + Vue.js + MySQL 8.0 + Docker

1. Introdução

1.1 Objetivo

Hoje, as programações que a fábrica manda para as bancas são controladas em papel e planilhas, e ninguém sabe ao certo onde está cada lote, quantos pares voltaram ou quanto se perdeu. Este sistema resolve isso: cada lote ganha um QR Code, lido pela webcam ou pelo celular na saída da fábrica, na chegada à banca e na volta.

1.2 Perfis de usuário

Administrador: cadastra usuários e bancas.

Gestor da fábrica: cria os lotes e acompanha o painel.

Operador da fábrica: lê o QR Code na saída do lote.

Operador da banca: lê o QR Code ao receber e ao devolver, registra perdas e só vê os lotes da própria banca.

1.3 Ciclo de status do lote

Aguardando envio → Enviado à Banca → Em Processamento → Concluído/Na Fábrica

Um lote também pode ser Cancelado, desde que ainda esteja em Aguardando envio.

2. Requisitos Funcionais (RF)

2.1 Acesso e cadastros

RF01: cada pessoa entra com e-mail e senha e só acessa o que o seu perfil permite.

RF02: o administrador cadastra, edita e desativa usuários. Quem é operador de banca fica ligado a uma banca.

RF03: o administrador cadastra as bancas, com nome, CPF/CNPJ, responsável e telefone.

RF04: o sistema guarda os serviços terceirizados (ex.: pesponto, costura, colagem) com o valor por par. Mudar o valor não altera os lotes que já foram criados.

2.2 Lotes

RF05: o gestor cria o lote informando número da programação, modelo, cor, banca, serviço, prazo de retorno e quantos pares há em cada numeração. A soma é o total do lote.

RF06: cada lote recebe um código único (ex.: L-2026-000123) e um QR Code que leva só esse código.

RF07: o gestor imprime a etiqueta do lote, com QR Code, código, banca e quantidade de pares. Reimprimir não muda o código.

RF08: o lote só pode ser editado ou cancelado antes de sair da fábrica, e o cancelamento pede um motivo.

RF09: a lista de lotes tem busca por código e filtros por status, banca e período.

2.3 Leitura do QR Code

RF10: a tela de leitura abre a câmera (webcam no computador, câmera do celular) e lê o QR Code sozinha, sem botão de captura.

RF11: na saída, o operador da fábrica lê o QR Code e o lote passa para Enviado à Banca.

RF12: na chegada, o operador da banca lê o mesmo QR Code e o lote passa para Em Processamento. Se o lote for de outra banca, o sistema avisa e não registra.

RF13: na devolução, o operador da banca lê o QR Code de novo e o lote vira Concluído/Na Fábrica.

RF14: cada leitura guarda quem leu, quando e qual era o status antes. Esse histórico não pode ser editado nem apagado.

RF15: se a leitura estiver fora de ordem ou repetida, o sistema recusa e explica o motivo (ex.: “esse lote já está Em Processamento”).

RF16: se o QR Code estiver amassado ou a câmera falhar, dá para digitar o código do lote.

RF17: a leitura responde na hora: tela verde quando deu certo, vermelha com o motivo quando não deu.

2.4 Perdas e valores

RF18: enquanto o lote está em processamento, ou na hora de devolvê-lo, o operador da banca registra as perdas: tipo (danificada, extraviada ou defeito de fabricação), quantidade de pares e uma observação.

RF19: as perdas somadas não podem passar do total de pares do lote.

RF20: o sistema calcula os pares aprovados e o percentual de perda. Exemplo: 8 perdas em 300 pares dão 292 aprovados e 2,67% de perda.

RF21: o valor devido à banca é pares aprovados × valor por par do serviço, somado por banca e por mês.

2.5 Painel de acompanhamento

RF22: o painel mostra quantos lotes estão em cada status e se atualiza sozinho.

RF23: o painel mostra o tempo médio de ciclo (da saída ao retorno), o total de perdas e quais lotes estão atrasados.

RF24: o gestor abre qualquer lote e vê a linha do tempo completa, com cada etapa, data, hora e responsável, mais as perdas.

RF25: o painel pode ser filtrado por período, banca e status.

3. Requisitos Não Funcionais (RNF)

3.1 Tecnologia

RNF01: o backend é feito em Java com Spring Boot e expõe uma API REST.

RNF02: o frontend é feito em Vue.js e conversa com essa API.

RNF03: o banco de dados é MySQL 8.0.

RNF04: a leitura do QR Code acontece no navegador, com uma biblioteca JavaScript (ex.: html5-qrcode).

3.2 Usabilidade e hardware

RNF05: o leitor funciona primeiro pela webcam do computador e, como alternativa, pela câmera do celular, sempre no navegador e sem instalar aplicativo.

RNF06: as telas se ajustam a computador, tablet e celular.

RNF07: ler um lote não deve exigir mais do que apontar a câmera.

RNF08: o QR Code da etiqueta é grande (pelo menos 3 × 3 cm) para ser lido mesmo sujo ou amassado.

RNF09: a câmera só funciona em HTTPS (ou em localhost), então o README explica como publicar o sistema assim.

3.3 Implantação e portabilidade

RNF10: um docker-compose.yml na raiz do projeto sobe o banco (MySQL 8.0, com volume que guarda os dados) e o backend (.jar) com um único docker compose up.

RNF11: senhas e configurações ficam num arquivo .env, nunca dentro do código.

RNF12: o README ensina a subir o sistema do zero em qualquer computador com Docker, e há dados de demonstração para testar.

3.4 Desempenho e operação

RNF13: da câmera apontada até a confirmação na tela, a leitura leva no máximo 2 segundos.

RNF14: a leitura não trava a tela: a câmera fica pronta para o próximo lote logo em seguida.

RNF15: o painel abre em até 3 segundos e as listas são paginadas.

3.5 Segurança, dados e projeto

RNF16: as senhas são guardadas com criptografia (BCrypt) e o login usa um token que expira.

RNF17: cada pessoa só vê o que o seu perfil permite; o QR Code de outra banca não mostra nada a quem não tem acesso.

RNF18: a mudança de status e o histórico são gravados juntos: ou entra tudo, ou nada.

RNF19: o código é versionado em Git, com as branches main, develop, feature/... e test/..., e passa por testes antes de entrar na develop.

RNF20: o desenvolvimento segue Scrum, e a entrega inclui casos de uso, DER e diagrama de sequência (e, se der tempo, o diagrama de classes).

RNF21: tudo em português do Brasil, com datas em dd/mm/aaaa e horário de Brasília.

4. Pontos para confirmar

Leitura de retorno: seguimos a proposta, em que quem devolve o lote é a banca. Confirmar com o professor (Product Owner).

Perdas em pares: a proposta fala em “peças”; aqui a contagem é em pares.

Defeito de fabricação: por enquanto reduz os pares aprovados e o valor devido, como qualquer outra perda. Confirmar se deve descontar da banca.

Exemplos: o lote L-2026-000123 e os números citados são só para ilustrar.
