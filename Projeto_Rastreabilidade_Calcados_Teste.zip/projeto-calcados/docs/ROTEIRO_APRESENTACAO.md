# Roteiro de apresentação

## Preparação

Suba Docker, imprima uma etiqueta de teste, confirme webcam/HTTPS e ensaie o fluxo. Use uma base de demonstração, sem dados de clientes. Tenha o código manual disponível caso o dispositivo falhe. Distribua os blocos entre os alunos sem inventar responsabilidades retroativas.

1. **Problema (1 min):** papéis e planilhas não mostram com clareza onde o lote está, quanto se perdeu e quanto pagar.
2. **Solução (1 min):** mesmo QR acompanha fábrica → banca → fábrica. Mostre os quatro perfis.
3. **Arquitetura (2 min):** Vue apresenta, Spring valida, MySQL persiste, Docker reproduz. Abra o DER.
4. **Cadastros (1 min):** administrador mantém banca, operador vinculado e serviço de R$ 2,50.
5. **Lote (2 min):** gestor cria 300 pares; explique grade, total e preço contratado. Mostre a etiqueta de 4 cm.
6. **Saída e recebimento (2 min):** operador da fábrica envia; operador da banca recebe. Use a câmera. Demonstre rejeição de repetição.
7. **Perdas e retorno (2 min):** registre 8 pares perdidos e devolva. Mostre 292 aprovados, 2,67% e R$ 730,00.
8. **Painel e linha do tempo (2 min):** mostre todos os responsáveis/horários, filtros, atualização automática, ciclo e atraso.
9. **Segurança e testes (2 min):** tente outra banca, mostre a transação e o teste de rollback. Explique que esconder botão sozinho não protege uma API.
10. **Entrega (1 min):** apresente matriz RF/RNF, README, Git e o relatório de validação. Explicite os testes físicos e de infraestrutura ainda pendentes, se não tiverem sido executados pela turma.

Perguntas para se preparar: por que guardar preço no lote? O que ocorre se dois operadores registrarem perda juntos? Por que HTTPS é necessário? Como o sistema impede que um QR de outra banca revele dados? Qual diferença entre previsão e valor devido? O que uma transação garante?
