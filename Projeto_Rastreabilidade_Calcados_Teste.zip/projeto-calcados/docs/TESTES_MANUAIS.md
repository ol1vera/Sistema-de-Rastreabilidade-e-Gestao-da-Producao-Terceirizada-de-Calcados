# Homologação manual e desempenho

Não marque uma linha como aprovada sem executá-la. Registre navegador/versão, sistema, dispositivo, rede, quantidade de lotes, data e responsável.

| Cenário | Procedimento | Resultado esperado |
|---|---|---|
| Webcam | Abrir leitor no localhost e autorizar câmera | Vídeo e leitura automática sem botão de captura |
| Smartphone | Abrir por HTTPS confiável e autorizar câmera | Câmera traseira preferida; tela adaptada |
| Permissão negada | Negar câmera | Mensagem em português, código manual permanece funcional |
| Sem webcam | Desconectar dispositivo | Falha tratada, sem travar navegação |
| Etiqueta | Imprimir em 100% e medir QR | 4 cm por 4 cm, nunca menor que 3 cm |
| Leitura contínua | Deixar a mesma etiqueta diante da câmera | Uma requisição durante leitura contínua |
| Nova leitura | Retirar por mais de 2,5 s e reapresentar | Servidor recusa etapa repetida, sem novo histórico |
| Próximo lote | Apresentar outro QR após confirmação | Leitura pronta sem recarregar a página |
| Etiqueta danificada | Dobrar levemente ou sujar parcialmente | Verificar leitura; usar manual se não decodificar |
| Falha de conexão | Desligar rede durante operação | Aviso; restabelecer rede, consultar status antes de repetir |
| Código manual | Digitar lote em cada ação | Mesmas regras/permissões que a câmera |
| Outra banca | Tentar código de banca diferente | Sem detalhe, imagem, perdas ou movimento acessíveis |
| Retorno | Registrar perdas e devolver | Total financeiro correto e novas perdas bloqueadas |
| Impressão repetida | Reimprimir etiqueta | Mesmo conteúdo QR e mesmo identificador |
| Responsividade | Larguras 360, 768 e 1440 px | Campos utilizáveis, tabela com rolagem, navegação acessível |
| Sessão vencida | Token curto em ambiente de teste, aguardar | Nova requisição retorna 401 e login |
| Persistência | Reiniciar Compose sem remover volume | Cadastros, lotes e histórico permanecem |

## RNF13 — Até 2 segundos

Use gravação de tela com relógio ou cronômetro de vídeo. Meça desde a etiqueta totalmente visível no enquadramento até a confirmação verde. Faça pelo menos 30 leituras distintas em iluminação normal; relate mínimo, mediana, p95 e máximo, e quantas ultrapassaram 2 s. O valor em ms mostrado pelo leitor mede requisição/interface após decodificação, portanto **não prova sozinho RNF13**. Não execute movimentos fora de ordem para medir o caso de sucesso.

## RNF15 — Painel em até 3 segundos

Com a aplicação aquecida e uma base de teste representativa (ex.: 10 mil lotes), meça da navegação ao painel até gráficos e indicadores prontos. Faça 30 repetições por perfil de rede/dispositivo. Relate p95 e máximo e registre o volume. Verifique índices com EXPLAIN no MySQL se houver lentidão. Nenhum resultado de desempenho foi inventado nesta entrega.

## Testes de MySQL

Rode `RUN_MYSQL_TESTS=true mvn test` com Docker. Valide Flyway, Hibernate ddl validate, queries agregadas e triggers. H2 não comprova compatibilidade do dialeto MySQL nem as garantias reais do InnoDB.
