-- Histórico permanente inclusive contra SQL acidental. Administradores do banco ainda podem alterar o esquema.
CREATE TRIGGER movimentacoes_sem_update BEFORE UPDATE ON movimentacoes FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Historico imutavel';
CREATE TRIGGER movimentacoes_sem_delete BEFORE DELETE ON movimentacoes FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Historico imutavel';
CREATE TRIGGER perdas_sem_update BEFORE UPDATE ON perdas FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Perda imutavel';
CREATE TRIGGER perdas_sem_delete BEFORE DELETE ON perdas FOR EACH ROW SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Perda imutavel';
