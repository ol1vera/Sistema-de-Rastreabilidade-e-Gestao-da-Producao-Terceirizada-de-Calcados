package br.edu.senai.rastreio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/** Ponto de entrada: inicializa a API e as camadas de persistência e segurança. */
@SpringBootApplication
public class RastreioApplication {
  public static void main(String[] args) {
    SpringApplication.run(RastreioApplication.class, args);
  }
}
