package br.edu.senai.rastreio.exception;

/** Erro esperado de negócio, com resposta HTTP segura para o operador. */
public class RegraException extends RuntimeException {
  public final int status;

  public RegraException(int status, String mensagem) {
    super(mensagem);
    this.status = status;
  }
}
