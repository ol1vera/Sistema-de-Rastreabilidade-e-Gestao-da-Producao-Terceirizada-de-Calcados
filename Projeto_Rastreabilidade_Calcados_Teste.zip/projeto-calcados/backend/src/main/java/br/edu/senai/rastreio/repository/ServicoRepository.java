package br.edu.senai.rastreio.repository;

import br.edu.senai.rastreio.entity.Servico;
import org.springframework.data.jpa.repository.*;

/** Acesso parametrizado aos registros; lotes usam bloqueio ao movimentar. */
public interface ServicoRepository
    extends JpaRepository<Servico, Long>, JpaSpecificationExecutor<Servico> {}
