package br.edu.senai.rastreio.config;

import java.time.*;
import org.springframework.boot.autoconfigure.validation.ValidationConfigurationCustomizer;
import org.springframework.context.annotation.*;

/** Valida prazos no mesmo fuso usado pelo negócio, independentemente do servidor. */
@Configuration
public class ValidacaoConfig {
  @Bean
  ValidationConfigurationCustomizer horarioBrasilia() {
    return c -> c.clockProvider(() -> Clock.system(ZoneId.of("America/Sao_Paulo")));
  }
}
