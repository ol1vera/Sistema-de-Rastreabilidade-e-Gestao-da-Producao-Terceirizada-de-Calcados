package br.edu.senai.rastreio.repository;

import br.edu.senai.rastreio.entity.Movimentacao;
import org.springframework.data.jpa.repository.*;

/** Acesso parametrizado aos registros; lotes usam bloqueio ao movimentar. */
public interface MovimentacaoRepository
    extends JpaRepository<Movimentacao, Long>, JpaSpecificationExecutor<Movimentacao> {
  java.util.List<Movimentacao> findByLoteIdOrderByOcorridoEmAscIdAsc(Long id);
}
