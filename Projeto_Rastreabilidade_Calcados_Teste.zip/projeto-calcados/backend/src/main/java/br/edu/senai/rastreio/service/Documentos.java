package br.edu.senai.rastreio.service;

/** Validação dos dígitos verificadores do CPF e CNPJ numérico. */
public class Documentos {
  public static boolean valido(String d) {
    if (d == null || !d.matches("[0-9]{11}|[0-9]{14}") || d.chars().distinct().count() == 1)
      return false;
    int[] pesos =
        d.length() == 11
            ? new int[] {10, 9, 8, 7, 6, 5, 4, 3, 2}
            : new int[] {5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2};
    int soma = 0;
    for (int i = 0; i < pesos.length; i++) soma += (d.charAt(i) - '0') * pesos[i];
    int primeiro = soma % 11 < 2 ? 0 : 11 - soma % 11;
    if (primeiro != d.charAt(pesos.length) - '0') return false;
    int[] outros =
        d.length() == 11
            ? new int[] {11, 10, 9, 8, 7, 6, 5, 4, 3, 2}
            : new int[] {6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2};
    soma = 0;
    for (int i = 0; i < outros.length; i++) soma += (d.charAt(i) - '0') * outros[i];
    return (soma % 11 < 2 ? 0 : 11 - soma % 11) == d.charAt(outros.length) - '0';
  }
}
