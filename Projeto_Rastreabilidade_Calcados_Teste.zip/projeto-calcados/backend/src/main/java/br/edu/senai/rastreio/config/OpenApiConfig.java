package br.edu.senai.rastreio.config;

import io.swagger.v3.oas.models.*;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.security.*;
import org.springframework.context.annotation.*;

/** Documentação pública da API; dados operacionais continuam exigindo token. */
@Configuration
public class OpenApiConfig {
  @Bean
  OpenAPI documentacao() {
    return new OpenAPI()
        .info(
            new Info()
                .title("Rastreio — API de produção")
                .version("1.0.0")
                .description(
                    "Fluxo de lotes, perdas e rastreabilidade. Faça login para obter um token e use"
                        + " Authorize."))
        .components(
            new Components()
                .addSecuritySchemes(
                    "bearerAuth",
                    new SecurityScheme()
                        .type(SecurityScheme.Type.HTTP)
                        .scheme("bearer")
                        .bearerFormat("JWT")))
        .addSecurityItem(new SecurityRequirement().addList("bearerAuth"));
  }
}
