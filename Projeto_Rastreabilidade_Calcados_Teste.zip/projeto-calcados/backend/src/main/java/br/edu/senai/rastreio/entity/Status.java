package br.edu.senai.rastreio.entity;

/** Valores fechados usados nas validações do domínio. */
public enum Status {
  AGUARDANDO_ENVIO,
  ENVIADO_BANCA,
  EM_PROCESSAMENTO,
  CONCLUIDO,
  CANCELADO
}
