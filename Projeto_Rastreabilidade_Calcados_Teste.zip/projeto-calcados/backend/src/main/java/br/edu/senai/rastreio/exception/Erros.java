package br.edu.senai.rastreio.exception;

import java.util.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;

/** Nunca devolve SQL, senhas ou stack traces ao navegador. */
@RestControllerAdvice
public class Erros {
  @ExceptionHandler(RegraException.class)
  ResponseEntity<?> regra(RegraException e) {
    return resposta(e.status, e.getMessage());
  }

  @ExceptionHandler(MethodArgumentNotValidException.class)
  ResponseEntity<?> validacao(MethodArgumentNotValidException e) {
    Map<String, String> campos = new LinkedHashMap<>();
    e.getBindingResult()
        .getFieldErrors()
        .forEach(x -> campos.put(x.getField(), "Valor obrigatório ou inválido."));
    return ResponseEntity.badRequest()
        .body(Map.of("mensagem", "Revise os campos informados.", "campos", campos));
  }

  @ExceptionHandler({
    org.springframework.dao.DataIntegrityViolationException.class,
    org.springframework.dao.ConcurrencyFailureException.class
  })
  ResponseEntity<?> conflito(Exception e) {
    return resposta(
        409,
        "Registro duplicado, vinculado ou alterado por outro usuário. Atualize e tente novamente.");
  }

  @ExceptionHandler({
    org.springframework.http.converter.HttpMessageNotReadableException.class,
    org.springframework.web.method.annotation.MethodArgumentTypeMismatchException.class,
    IllegalArgumentException.class
  })
  ResponseEntity<?> entrada(Exception e) {
    return resposta(400, "Dados ou filtros inválidos.");
  }

  @ExceptionHandler(org.springframework.security.access.AccessDeniedException.class)
  ResponseEntity<?> proibido(Exception e) {
    return resposta(403, "Acesso não autorizado.");
  }

  @ExceptionHandler(Exception.class)
  ResponseEntity<?> inesperado(Exception e) {
    org.slf4j.LoggerFactory.getLogger(Erros.class).error("Falha interna", e);
    return resposta(500, "Não foi possível concluir. Tente novamente.");
  }

  private ResponseEntity<?> resposta(int status, String msg) {
    return ResponseEntity.status(status).body(Map.of("mensagem", msg));
  }
}
