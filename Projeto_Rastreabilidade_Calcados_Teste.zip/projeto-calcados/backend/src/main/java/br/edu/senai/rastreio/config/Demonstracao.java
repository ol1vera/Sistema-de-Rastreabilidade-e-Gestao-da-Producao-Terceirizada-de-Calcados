package br.edu.senai.rastreio.config;

import br.edu.senai.rastreio.entity.*;
import br.edu.senai.rastreio.repository.*;
import java.math.BigDecimal;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/** Carga opcional, idempotente e sem senha fixa; não sobrescreve cadastros existentes. */
@Component
public class Demonstracao implements CommandLineRunner {
  private final UsuarioRepository usuarios;
  private final BancaRepository bancas;
  private final ServicoRepository servicos;
  private final PasswordEncoder encoder;
  private final boolean enabled;
  private final String password;

  public Demonstracao(
      UsuarioRepository u,
      BancaRepository b,
      ServicoRepository s,
      PasswordEncoder e,
      @Value("${app.demo-enabled}") boolean enabled,
      @Value("${app.demo-password}") String password) {
    usuarios = u;
    bancas = b;
    servicos = s;
    encoder = e;
    this.enabled = enabled;
    this.password = password;
  }

  @Override
  @Transactional
  public void run(String... args) {
    if (!enabled) return;
    if (password.length() < 10
        || password.getBytes(java.nio.charset.StandardCharsets.UTF_8).length > 72)
      throw new IllegalArgumentException(
          "DEMO_PASSWORD deve ter 10 caracteres ou mais e até 72 bytes.");
    if (usuarios.count() > 0) return;
    var b = new Banca();
    b.nome = "Banca Horizonte (demonstração)";
    b.documento = "11222333000181";
    b.responsavel = "Responsável de demonstração";
    b.telefone = "37999990000";
    bancas.save(b);
    var s = new Servico();
    s.nome = "Pesponto";
    s.descricao = "Serviço de demonstração";
    s.valorPar = new BigDecimal("2.50");
    servicos.save(s);
    for (var p : Perfil.values()) {
      var u = new Usuario();
      u.nome =
          switch (p) {
            case ADMIN -> "Administrador";
            case GESTOR -> "Gestor da fábrica";
            case OPERADOR_FABRICA -> "Operador da fábrica";
            case OPERADOR_BANCA -> "Operador da banca";
          };
      u.email =
          switch (p) {
            case ADMIN -> "admin@demo.local";
            case GESTOR -> "gestor@demo.local";
            case OPERADOR_FABRICA -> "fabrica@demo.local";
            case OPERADOR_BANCA -> "banca@demo.local";
          };
      u.senha = encoder.encode(password);
      u.perfil = p;
      if (p == Perfil.OPERADOR_BANCA) u.banca = b;
      usuarios.save(u);
    }
  }
}
