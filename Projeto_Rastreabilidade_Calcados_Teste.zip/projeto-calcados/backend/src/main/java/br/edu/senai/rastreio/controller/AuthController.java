package br.edu.senai.rastreio.controller;

import br.edu.senai.rastreio.dto.Entradas.Login;
import br.edu.senai.rastreio.exception.RegraException;
import br.edu.senai.rastreio.repository.UsuarioRepository;
import br.edu.senai.rastreio.security.Acesso;
import jakarta.validation.Valid;
import java.time.Instant;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.*;
import org.springframework.web.bind.annotation.*;

/** Autenticação com BCrypt; resposta não contém hash de senha. */
@RestController
@RequestMapping("/api/auth")
public class AuthController {
  private final UsuarioRepository usuarios;
  private final PasswordEncoder senhas;
  private final JwtEncoder encoder;
  private final Acesso acesso;
  private final long minutos;

  public AuthController(
      UsuarioRepository u,
      PasswordEncoder s,
      JwtEncoder e,
      Acesso a,
      @Value("${app.token-minutes}") long minutos) {
    usuarios = u;
    senhas = s;
    encoder = e;
    acesso = a;
    this.minutos = minutos;
  }

  @PostMapping("/login")
  public Map<String, Object> login(@Valid @RequestBody Login entrada) {
    var u =
        usuarios
            .findByEmail(entrada.email().trim().toLowerCase())
            .orElseThrow(() -> new RegraException(401, "E-mail ou senha inválidos."));
    if (!u.ativo || !senhas.matches(entrada.senha(), u.senha))
      throw new RegraException(401, "E-mail ou senha inválidos.");
    var agora = Instant.now();
    var claims =
        JwtClaimsSet.builder()
            .issuer("rastreio")
            .subject(u.id.toString())
            .issuedAt(agora)
            .expiresAt(agora.plusSeconds(minutos * 60))
            .build();
    var token =
        encoder
            .encode(JwtEncoderParameters.from(JwsHeader.with(MacAlgorithm.HS256).build(), claims))
            .getTokenValue();
    return Map.of("token", token, "usuario", u, "expiraEm", agora.plusSeconds(minutos * 60));
  }

  @GetMapping("/me")
  public Object me() {
    return acesso.atual();
  }
}
