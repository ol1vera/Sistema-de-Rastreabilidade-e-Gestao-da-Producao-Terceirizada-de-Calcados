package br.edu.senai.rastreio.entity;

/** Valores fechados usados nas validações do domínio. */
public enum Perfil {
  ADMIN,
  GESTOR,
  OPERADOR_FABRICA,
  OPERADOR_BANCA
}
