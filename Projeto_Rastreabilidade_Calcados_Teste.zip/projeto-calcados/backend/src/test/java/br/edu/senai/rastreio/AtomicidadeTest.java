package br.edu.senai.rastreio;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import br.edu.senai.rastreio.entity.*;
import br.edu.senai.rastreio.repository.MovimentacaoRepository;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.bean.override.mockito.MockitoSpyBean;

/** Uma falha no histórico deve desfazer a mudança de status. */
@ActiveProfiles("test")
class AtomicidadeTest extends FluxoBase {
  @MockitoSpyBean MovimentacaoRepository movimentos;

  @Test
  void rollbackQuandoHistoricoFalha() throws Exception {
    String codigo = criar();
    doThrow(new IllegalStateException("Falha simulada no histórico"))
        .when(movimentos)
        .saveAndFlush(any(Movimentacao.class));
    try {
      mover(codigo, "enviar", Perfil.OPERADOR_FABRICA, 500);
      assertEquals(Status.AGUARDANDO_ENVIO, lotes.findByCodigo(codigo).orElseThrow().status);
    } finally {
      reset(movimentos);
    }
  }
}
