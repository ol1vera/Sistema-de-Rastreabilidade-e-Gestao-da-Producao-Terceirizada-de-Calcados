package br.edu.senai.rastreio;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import java.time.Instant;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.*;
import org.springframework.test.context.ActiveProfiles;

/** H2 é exclusivamente um auxiliar de testes; aplicação e Docker usam MySQL. */
@ActiveProfiles("test")
class IntegracaoTest extends FluxoBase {
  @Autowired JwtEncoder encoderJwt;

  @Test
  void tokenExpiradoERecusado() throws Exception {
    var agora = Instant.now();
    var claims =
        JwtClaimsSet.builder()
            .issuer("rastreio")
            .subject(operador.id.toString())
            .issuedAt(agora.minusSeconds(7200))
            .expiresAt(agora.minusSeconds(3600))
            .build();
    var token =
        encoderJwt
            .encode(JwtEncoderParameters.from(JwsHeader.with(MacAlgorithm.HS256).build(), claims))
            .getTokenValue();
    chamada(get("/api/lotes"), token, null, 401);
  }
}
