package br.edu.senai.rastreio;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfEnvironmentVariable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.MySQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

/**
 * Execute RUN_MYSQL_TESTS=true mvn test em uma máquina com Docker. Migrações reais são validadas.
 */
@Testcontainers
@EnabledIfEnvironmentVariable(named = "RUN_MYSQL_TESTS", matches = "true")
class MySqlTest extends FluxoBase {
  @Container
  static MySQLContainer<?> mysql =
      new MySQLContainer<>("mysql:8.0").withCommand("--log-bin-trust-function-creators=1");

  @Autowired JdbcTemplate jdbc;

  @DynamicPropertySource
  static void propriedades(DynamicPropertyRegistry r) {
    r.add("spring.datasource.url", mysql::getJdbcUrl);
    r.add("spring.datasource.username", mysql::getUsername);
    r.add("spring.datasource.password", mysql::getPassword);
    r.add("app.jwt-secret", () -> "chave-isolada-de-teste-mysql-com-mais-de-32-bytes");
    r.add("app.demo-enabled", () -> false);
  }

  @Test
  void bancoRecusaEdicaoEExclusaoDeHistorico() throws Exception {
    String c = criar();
    Long id = lotes.findByCodigo(c).orElseThrow().id;
    assertThrows(
        org.springframework.dao.DataAccessException.class,
        () -> jdbc.update("UPDATE movimentacoes SET tipo='ALTERADO' WHERE lote_id=?", id));
    assertThrows(
        org.springframework.dao.DataAccessException.class,
        () -> jdbc.update("DELETE FROM movimentacoes WHERE lote_id=?", id));
  }
}
