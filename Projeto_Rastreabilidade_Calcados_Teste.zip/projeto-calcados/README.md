# Rastreio — Produção terceirizada de calçados

Projeto acadêmico SENAI Nova Serrana. Aplicação com Vue 3, API Java 17 / Spring Boot 3.5.7, MySQL 8.0 e Docker. Os arquivos de referência estão transcritos em `docs/REQUISITOS_ORIGINAIS.md`. Comece pelo relatório `docs/VALIDACAO.md` para saber o que foi efetivamente verificado.

## Começar no Windows (Docker Desktop)

1. Instale e abra o Docker Desktop, usando containers Linux. Aguarde o motor ficar ativo.
2. Extraia este ZIP em uma pasta, por exemplo `C:\Projetos\rastreio`.
3. Abra o terminal nessa pasta, onde está `docker-compose.yml`.
4. Copie `.env.example` para `.env` (PowerShell: `Copy-Item .env.example .env`). No Explorador, arquivos começando com ponto podem ficar pouco visíveis.
5. Edite `.env`: defina senhas diferentes para o banco e root; defina `JWT_SECRET` com pelo menos 32 bytes aleatórios (recomendado 64 caracteres); defina a senha da demonstração com 10 ou mais caracteres, até 72 bytes. Não envie esse arquivo ao GitHub.
6. Execute:

```sh
docker compose up --build
```

7. Na primeira execução, aguarde o download das imagens, a compilação e o início do Spring Boot. Abra **http://localhost:8081**.

No Linux/macOS use `cp .env.example .env`. As demais instruções são iguais. Internet é necessária na primeira construção. O projeto não exige Maven ou Node instalados na máquina quando usado via Docker.

### Acessos de demonstração

Todos usam a senha **que você definiu em `DEMO_PASSWORD`**. Não há senha real embutida no código.

| E-mail | Perfil | Função |
|---|---|---|
| admin@demo.local | Administrador | Bancas, serviços e usuários |
| gestor@demo.local | Gestor da fábrica | Lotes, etiquetas, painel e financeiro |
| fabrica@demo.local | Operador da fábrica | Leitura de saída |
| banca@demo.local | Operador da banca | Recebimento, perdas e devolução |

A carga cria uma banca e o serviço Pesponto a R$ 2,50. Os dados são exemplos, não cadastros reais. Não cria lotes fictícios no painel: faça o primeiro lote como gestor. A carga só roda se `DEMO_ENABLED=true` e não houver usuários. Não sobrescreve dados existentes nem redefine senhas ao reiniciar.

### Primeiro teste completo

1. Entre como gestor, crie um lote de 300 pares para a banca de demonstração, serviço Pesponto e prazo futuro.
2. Abra o detalhe, copie o código e imprima a etiqueta em escala 100%.
3. Saia. Entre como operador da fábrica, abra Leitura e registre a saída por QR ou código manual.
4. Saia. Entre como operador da banca e registre Recebimento.
5. Abra o detalhe e registre 8 pares danificados com observação.
6. No leitor, selecione Devolução e leia novamente.
7. Entre como gestor: confira 292 aprovados, 2,67% de perdas, R$ 730,00 devidos e quatro eventos no histórico (criação e três movimentações).

### Endereços

- Interface: http://localhost:8081
- API local: http://localhost:8080/api
- Saúde: http://localhost:8080/actuator/health
- OpenAPI: http://localhost:8080/v3/api-docs.
- Swagger UI: http://localhost:8080/swagger-ui.html. Faça login no endpoint `/api/auth/login`, copie o token retornado e clique em **Authorize**. A documentação é pública; os dados continuam protegidos.

O MySQL não é exposto no host. O frontend acessa `/api`, encaminhado pelo Nginx ao backend. Apenas a porta local 8080 do backend é publicada. O frontend usa 8081 (altere `FRONTEND_PORT` se necessário).

### Operação

```sh
docker compose logs -f backend
docker compose ps
docker compose down
docker compose up -d
```

`down` sem `-v` preserva o banco. **Não use `down -v` quando precisar manter os dados.** As migrações Flyway são incrementais. Não altere migrações já aplicadas: crie V3, V4 etc.

## Câmera, smartphone e HTTPS

A webcam funciona em `http://localhost` no próprio computador. No celular, um IP como `http://192.168...` não é contexto seguro: é necessário HTTPS com certificado confiável. O código manual continua disponível.

Para publicar em servidor: configure um domínio, DNS e proxy HTTPS (ex.: Caddy ou Nginx com certificado válido) encaminhando para a porta do frontend. Exemplo Caddy em `infra/Caddyfile.example`; use um domínio real e ajuste o destino. Não abra o MySQL na internet. Primeiro valide localmente, depois configure contas reais, `DEMO_ENABLED=false`, segredos próprios e backups. A hospedagem Java/MySQL não foi publicada nesta entrega.

Permita o uso da câmera no navegador; verifique se outro programa está usando a webcam. A leitura prefere câmera traseira quando disponível. A etiqueta tem QR de **4 × 4 cm** com margem e correção H. Danos severos ainda podem impedir a leitura; não há garantia de leitura de qualquer etiqueta amassada.

## Desenvolvimento sem Docker

Exige Java 17, Maven 3.9+, Node 22, npm e MySQL 8.0 disponível. Configure `DB_URL`, `DB_USER`, `DB_PASSWORD`, `JWT_SECRET`, `DEMO_ENABLED` e `DEMO_PASSWORD` como variáveis do processo. O Spring não lê automaticamente o `.env` fora do Compose.

```sh
cd backend
mvn spring-boot:run
```

Em outro terminal:

```sh
cd frontend
npm ci
npm run dev
```

O Vite usa http://localhost:5173 e encaminha `/api` ao Java em 8080.

## Testes

```sh
# Backend: unitários e integração auxiliar em H2 (somente testes)
cd backend
mvn test
# MySQL real, Flyway e proteção de histórico; exige Docker
RUN_MYSQL_TESTS=true mvn test
```

PowerShell para o teste MySQL: `$env:RUN_MYSQL_TESTS="true"; mvn test`. Para limpar a variável: `Remove-Item Env:RUN_MYSQL_TESTS`.

```sh
cd frontend
npm ci
npm test
npm run build
# Ponta a ponta: aplicação de demonstração precisa estar rodando
npx playwright install chromium
# Exporte DEMO_PASSWORD no terminal sem salvar no repositório.
npm run test:e2e
```

O E2E pressupõe o cadastro de demonstração sem alteração de nomes/preço. Leitura automática de webcam exige teste manual separado. Veja `docs/TESTES_MANUAIS.md` e os resultados reais em `docs/VALIDACAO.md`.

## Organização

```text
backend/       API REST, regras, segurança, migrações e testes Java
frontend/      Vue, componentes, câmera, gráficos e testes de interface
infra/         Exemplo de proxy HTTPS
docs/          Matriz, arquitetura, diagramas, Scrum e guia didático
tests/         Procedimentos de validação
```

## Decisões importantes

- Retorno registrado pela banca, conforme RF13 (confirmar com professor).
- Perdas em pares; defeito de fabricação também reduz o pagamento (confirmar responsabilidade).
- Competência financeira: data de conclusão no horário de Brasília. O painel/listagem filtram a data de criação.
- Identificador: `L-ANO-UUID` completo; o formato numérico sequencial dos requisitos é ilustrativo. Restrição UNIQUE no banco impede duplicação.
- Edição mantém o serviço e preço contratados. Para mudar serviço, cancele e crie outro lote.
- Sessão em memória: recarregar a página exige novo login. Token expira em 60 minutos, configurável; desativação bloqueia imediatamente novas chamadas.
- O logout remove o token da memória; um token copiado anteriormente mantém validade até expirar, salvo se o usuário for desativado. Não há endpoint de renovação.
- Sem exclusão física de cadastros pela API. Histórico/perdas não têm rotas de edição ou exclusão.

## Problemas comuns

- **Frontend abre antes da API:** aguarde o log `Started RastreioApplication` e tente entrar novamente.
- **Erro de conexão com banco:** revise as senhas. Alterar `.env` após o banco ter sido criado não altera a senha gravada no volume. Atualize a conta no MySQL ou restaure o `.env` correto; não apague dados para corrigir isso.
- **Login não funciona:** use a senha definida na primeira inicialização; confirme `DEMO_ENABLED=true` para uma base vazia.
- **Porta ocupada:** altere `FRONTEND_PORT`; para 8080 ajuste o mapeamento do backend.
- **Erro 409:** operação repetida, etapa inválida, duplicidade de cadastro ou limite de perdas.
- **Erro 404 em lote de outra banca:** comportamento de segurança intencional, sem revelar dados.
- **Câmera no celular não abre:** confira HTTPS e permissão. `localhost` do celular não é o computador.

## Documentação

- `docs/ARQUITETURA.md` — estrutura e decisões.
- `docs/MATRIZ_REQUISITOS.md` — 46 requisitos e evidências.
- `docs/GUIA_EXPLICACAO_CODIGO.md` — guia para explicar o funcionamento.
- `docs/CASOS_DE_USO.md`, `docs/DIAGRAMAS.md` — material acadêmico.
- `docs/SCRUM_E_GIT.md` — backlog e trabalho em equipe.
- `docs/ROTEIRO_APRESENTACAO.md` — roteiro de demonstração.
- `docs/VALIDACAO.md` — resultados, limitações e pendências.
