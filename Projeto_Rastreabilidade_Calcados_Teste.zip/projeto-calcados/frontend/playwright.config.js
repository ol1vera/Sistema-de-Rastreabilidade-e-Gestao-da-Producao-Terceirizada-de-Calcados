import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: "./e2e",
  timeout: 60000,
  use: {
    baseURL: process.env.E2E_BASE_URL || "http://localhost:8081",
    trace: "retain-on-failure",
  },
  reporter: "list",
  workers: 1,
});
