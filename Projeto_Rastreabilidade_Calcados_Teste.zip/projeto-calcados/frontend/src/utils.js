export const statusNomes = {
  AGUARDANDO_ENVIO: "Aguardando envio",
  ENVIADO_BANCA: "Enviado à banca",
  EM_PROCESSAMENTO: "Em processamento",
  CONCLUIDO: "Concluído / na fábrica",
  CANCELADO: "Cancelado",
};
export const perfis = {
  ADMIN: "Administrador",
  GESTOR: "Gestor da fábrica",
  OPERADOR_FABRICA: "Operador da fábrica",
  OPERADOR_BANCA: "Operador da banca",
};
export const tipos = {
  DANIFICADA: "Danificada",
  EXTRAVIADA: "Extraviada",
  DEFEITO_FABRICACAO: "Defeito de fabricação",
};
export const moeda = (v) =>
  v == null
    ? "—"
    : new Intl.NumberFormat("pt-BR", {
        style: "currency",
        currency: "BRL",
      }).format(v);
export const numero = (v) =>
  new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 2 }).format(v ?? 0);
export function dataBR(v, hora = false) {
  if (!v) return "—";
  if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return v.split("-").reverse().join("/");
  return new Intl.DateTimeFormat("pt-BR", {
    timeZone: "America/Sao_Paulo",
    dateStyle: "short",
    ...(hora ? { timeStyle: "short" } : {}),
  }).format(new Date(v));
}
export const hoje = () =>
  new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
export function mensagem(e) {
  return (
    e.response?.data?.mensagem ||
    "Não foi possível conectar ao servidor. Verifique a conexão e tente novamente."
  );
}
