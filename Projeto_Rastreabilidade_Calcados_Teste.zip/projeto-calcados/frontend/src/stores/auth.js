import { defineStore } from "pinia";
import { api } from "../api";
export const useAuth = defineStore("auth", {
  state: () => ({ token: null, usuario: null }),
  getters: {
    perfil: (s) => s.usuario?.perfil,
    gestao: (s) => ["ADMIN", "GESTOR"].includes(s.usuario?.perfil),
  },
  actions: {
    async entrar(email, senha) {
      const { data } = await api.post("/auth/login", { email, senha });
      this.token = data.token;
      this.usuario = data.usuario;
    },
    sair() {
      this.token = null;
      this.usuario = null;
    },
  },
});
// Token em memória: atualizar a página exige novo login, evitando armazenamento persistente.
