import { createApp } from "vue";
import { createPinia } from "pinia";
import App from "./App.vue";
import { router } from "./router";
import { api } from "./api";
import { useAuth } from "./stores/auth";
import "./style.css";
const app = createApp(App);
app.use(createPinia());
const auth = useAuth();
api.interceptors.request.use((config) => {
  if (auth.token) config.headers.Authorization = `Bearer ${auth.token}`;
  return config;
});
api.interceptors.response.use(
  (r) => r,
  (e) => {
    if (e.response?.status === 401 && auth.token) {
      auth.sair();
      router.push("/login");
    }
    return Promise.reject(e);
  },
);
app.use(router).mount("#app");
