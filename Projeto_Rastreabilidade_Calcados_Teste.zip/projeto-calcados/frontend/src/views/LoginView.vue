<script setup>
import { ref } from "vue";
import { useAuth } from "../stores/auth";
import { useRouter } from "vue-router";
import { useTask } from "../composables/useTask";
import Feedback from "../components/Feedback.vue";
const email = ref(""),
  senha = ref(""),
  auth = useAuth(),
  router = useRouter();
const { busy, erro, run } = useTask();
function entrar() {
  run(async () => {
    await auth.entrar(email.value, senha.value);
    router.push(auth.gestao ? "/" : "/leitor");
  });
}
</script>
<template>
  <div class="login-page">
    <section class="login-story">
      <div class="brand"><span class="brand-icon">R</span>rastreio</div>
      <div>
        <span class="eyebrow">DA FÁBRICA À BANCA. E DE VOLTA.</span>
        <h1>Cada par tem<br />uma história.<br /><em>Acompanhe todas.</em></h1>
        <p>Produção, movimentações e resultados em um só lugar.</p>
        <div class="steps">
          <span>01<br />Envio</span><span>02<br />Produção</span
          ><span>03<br />Retorno</span>
        </div>
      </div>
      <small>Sistema de rastreabilidade · SENAI Nova Serrana</small>
    </section>
    <section class="login-form">
      <form @submit.prevent="entrar">
        <span class="eyebrow">BEM-VINDO AO RASTREIO</span>
        <h2>Acesse sua operação</h2>
        <p class="muted">Entre com o e-mail e a senha cadastrados.</p>
        <Feedback :erro="erro" /><label
          >E-mail<input
            v-model="email"
            type="email"
            autocomplete="username"
            placeholder="voce@empresa.com.br"
            required /></label
        ><label
          >Senha<input
            v-model="senha"
            type="password"
            autocomplete="current-password"
            required
            maxlength="72" /></label
        ><button :disabled="busy" class="wide">
          {{ busy ? "Entrando…" : "Entrar no sistema →" }}</button
        ><small class="muted"
          >Precisa de acesso? Fale com o administrador da sua fábrica.</small
        >
      </form>
    </section>
  </div>
</template>
