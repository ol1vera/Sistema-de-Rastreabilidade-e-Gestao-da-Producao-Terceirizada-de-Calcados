<script setup>
import { useAuth } from "./stores/auth";
import { useRouter } from "vue-router";
import { perfis } from "./utils";
const auth = useAuth(),
  router = useRouter();
function sair() {
  auth.sair();
  router.push("/login");
}
</script>
<template>
  <RouterView v-if="!auth.token" />
  <div class="shell" v-else>
    <aside class="sidebar">
      <RouterLink class="brand" to="/"
        ><span class="brand-icon">R</span
        ><span>rastreio<small>PRODUÇÃO CONECTADA</small></span></RouterLink
      >
      <span class="nav-label">ÁREA DE TRABALHO</span>
      <nav aria-label="Navegação principal">
        <RouterLink v-if="auth.gestao" to="/"
          >◈ <span>Visão geral</span></RouterLink
        ><RouterLink to="/lotes">▦ <span>Lotes de produção</span></RouterLink>
        <RouterLink
          v-if="['OPERADOR_FABRICA', 'OPERADOR_BANCA'].includes(auth.perfil)"
          to="/leitor"
          >▣ <span>Leitura de QR Code</span></RouterLink
        >
        <RouterLink v-if="auth.gestao" to="/financeiro"
          >▤ <span>Valores por banca</span></RouterLink
        >
        <template v-if="auth.perfil === 'ADMIN'"
          ><span class="nav-label">ADMINISTRAÇÃO</span
          ><RouterLink to="/cadastros/bancas">◇ <span>Bancas</span></RouterLink
          ><RouterLink to="/cadastros/servicos"
            >≡ <span>Serviços</span></RouterLink
          ><RouterLink to="/cadastros/usuarios"
            >◎ <span>Usuários</span></RouterLink
          ></template
        >
      </nav>
      <div class="sidebar-foot">
        <span class="dot"></span> Rastreabilidade de ponta a ponta<small
          >Projeto acadêmico · SENAI</small
        >
      </div>
    </aside>
    <div class="workspace">
      <header class="topbar">
        <span>Gestão da produção <span class="muted">/ Calçados</span></span>
        <div class="user">
          <span class="avatar">{{ auth.usuario.nome.slice(0, 1) }}</span
          ><span
            >{{ auth.usuario.nome
            }}<small>{{ perfis[auth.perfil] }}</small></span
          ><button class="ghost" @click="sair">Sair</button>
        </div>
      </header>
      <main><RouterView :key="$route.fullPath" /></main>
      <footer>Rastreio · Horários de Brasília</footer>
    </div>
  </div>
</template>
