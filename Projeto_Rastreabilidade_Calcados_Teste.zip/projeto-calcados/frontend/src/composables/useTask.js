import { ref } from "vue";
import { mensagem } from "../utils";
/** Bloqueia duplo envio e preserva o formulário quando a API recusa a operação. */
export function useTask() {
  const busy = ref(false),
    erro = ref(""),
    sucesso = ref(""),
    campos = ref({});
  async function run(fn) {
    if (busy.value) return;
    busy.value = true;
    erro.value = "";
    sucesso.value = "";
    campos.value = {};
    try {
      return await fn();
    } catch (e) {
      erro.value = mensagem(e);
      campos.value = e.response?.data?.campos || {};
    } finally {
      busy.value = false;
    }
  }
  return { busy, erro, sucesso, campos, run };
}
