import { describe, it, expect } from "vitest";
import { dataBR, moeda } from "./utils";
import { parametros } from "./api";
import { criarTrava } from "./scanGate";
describe("apresentação brasileira", () => {
  it("formata data sem deslocar o dia", () =>
    expect(dataBR("2026-10-16")).toBe("16/10/2026"));
  it("converte horário UTC para Brasília", () =>
    expect(dataBR("2026-10-16T02:30:00Z", true)).toContain("15/10/2026"));
  it("formata reais", () => expect(moeda(730)).toContain("730,00"));
  it("omite filtros vazios e mantém página zero", () =>
    expect(parametros({ bancaId: "", page: 0, status: null })).toEqual({
      page: 0,
    }));
});
describe("controle da câmera", () => {
  it("bloqueia repetição contínua e permite outro lote", async () => {
    let t = 10000,
      n = 0;
    const trava = criarTrava(() => t);
    await trava.executar("A", async () => n++);
    t += 100;
    await trava.executar("A", async () => n++);
    expect(n).toBe(1);
    await trava.executar("B", async () => n++);
    expect(n).toBe(2);
  });
  it("libera após ausência e após erro", async () => {
    let t = 10000;
    const trava = criarTrava(() => t);
    await expect(
      trava.executar("A", async () => {
        throw Error("offline");
      }),
    ).rejects.toThrow();
    t += 3000;
    expect(await trava.executar("A", async () => {})).toBe(true);
  });
  it("não sobrepõe requisições", async () => {
    const trava = criarTrava();
    let liberar;
    const a = trava.executar("A", () => new Promise((r) => (liberar = r)));
    expect(await trava.executar("B", async () => {})).toBe(false);
    liberar();
    await a;
  });
});
