import { mount } from "@vue/test-utils";
import { describe, it, expect, vi } from "vitest";
import Feedback from "./Feedback.vue";
import Pagination from "./Pagination.vue";
import StatusBadge from "./StatusBadge.vue";
import Login from "../views/LoginView.vue";
import { createPinia, setActivePinia } from "pinia";
import { api } from "../api";
import { useAuth } from "../stores/auth";
vi.mock("vue-router", () => ({ useRouter: () => ({ push: vi.fn() }) }));
describe("componentes operacionais", () => {
  it("mensagens acessíveis e carregamento", () => {
    const w = mount(Feedback, { props: { erro: "Sem acesso", busy: true } });
    expect(w.get('[role="alert"]').text()).toContain("Sem acesso");
    expect(w.get('[role="status"]').text()).toContain("Carregando");
  });
  it("paginação bloqueia limites e emite mudança", async () => {
    const w = mount(Pagination, { props: { page: 0, pages: 2, total: 30 } });
    expect(w.findAll("button")[0].attributes("disabled")).toBeDefined();
    await w.findAll("button")[1].trigger("click");
    expect(w.emitted("change")[0]).toEqual([1]);
  });
  it("traduz status", () =>
    expect(
      mount(StatusBadge, { props: { status: "EM_PROCESSAMENTO" } }).text(),
    ).toBe("Em processamento"));
  it("login envia formulário e guarda sessão", async () => {
    setActivePinia(createPinia());
    vi.spyOn(api, "post").mockResolvedValueOnce({
      data: { token: "teste", usuario: { nome: "Gestor", perfil: "GESTOR" } },
    });
    const w = mount(Login);
    await w.get('input[type="email"]').setValue("gestor@demo.local");
    await w.get('input[type="password"]').setValue("SenhaTeste123");
    await w.get("form").trigger("submit");
    await new Promise((r) => setTimeout(r, 0));
    expect(api.post).toHaveBeenCalledWith("/auth/login", {
      email: "gestor@demo.local",
      senha: "SenhaTeste123",
    });
    expect(useAuth().token).toBe("teste");
  });
});
