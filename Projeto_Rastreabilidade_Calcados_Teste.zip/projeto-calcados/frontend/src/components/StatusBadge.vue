<script setup>
import { statusNomes } from "../utils";
defineProps({ status: String });
</script>
<template>
  <span class="badge" :class="status">{{ statusNomes[status] || status }}</span>
</template>
