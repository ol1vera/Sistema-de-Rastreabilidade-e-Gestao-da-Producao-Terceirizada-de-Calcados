import { createRouter, createWebHashHistory } from "vue-router";
import { useAuth } from "./stores/auth";
const Login = () => import("./views/LoginView.vue");
const Dashboard = () => import("./views/DashboardView.vue");
const Lotes = () => import("./views/LotesView.vue");
const FormLote = () => import("./views/LoteFormView.vue");
const Detalhe = () => import("./views/LoteDetailView.vue");
const Leitor = () => import("./views/LeitorView.vue");
const Cadastro = () => import("./views/CadastroView.vue");
const Financeiro = () => import("./views/FinanceiroView.vue");
const gestao = ["ADMIN", "GESTOR"];
export const router = createRouter({
  history: createWebHashHistory(),
  routes: [
    { path: "/login", component: Login, meta: { public: true } },
    { path: "/", component: Dashboard, meta: { roles: gestao } },
    { path: "/lotes", component: Lotes },
    { path: "/lotes/novo", component: FormLote, meta: { roles: ["GESTOR"] } },
    {
      path: "/lotes/:codigo/editar",
      component: FormLote,
      meta: { roles: ["GESTOR"] },
    },
    { path: "/lotes/:codigo", component: Detalhe },
    {
      path: "/leitor",
      component: Leitor,
      meta: { roles: ["OPERADOR_FABRICA", "OPERADOR_BANCA"] },
    },
    {
      path: "/cadastros/:tipo",
      component: Cadastro,
      meta: { roles: ["ADMIN"] },
    },
    { path: "/financeiro", component: Financeiro, meta: { roles: gestao } },
    { path: "/:pathMatch(.*)*", redirect: "/" },
  ],
});
// A proteção visual melhora a navegação; a autorização verdadeira também existe na API.
router.beforeEach((to) => {
  const auth = useAuth();
  if (!to.meta.public && !auth.token) return "/login";
  if (to.meta.roles && !to.meta.roles.includes(auth.perfil)) return "/lotes";
});
